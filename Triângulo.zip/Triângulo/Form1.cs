﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triângulo
{
    public partial class Form1 : Form
    {
        double a, b, c;

        private void textA_TextChanged(object sender, EventArgs e)
        {
        }

        private void butLimpar_Click(object sender, EventArgs e)
        {
            textA.Text = "";
            textB.Clear();
            textC.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textA.Text == "" || textB.Text == "" || textC.Text == "")
                MessageBox.Show("Informar medidas do triângulo!");

            else
                {
                    if (double.TryParse(textA.Text, out a) &&
                        double.TryParse(textB.Text, out b) &&
                        double.TryParse(textC.Text, out c))

                        {
                            if ((b - c < a && a < b + c) && (a - c < b && b < a + c) && (a - b < c && c < a + b))
                                {
                                    if (a == b && b == c)
                                        MessageBox.Show("Triângulo Equilátero");
                                    else if (a == b || b == c || a == c)
                                        MessageBox.Show("Triângulo Isósceles");
                                    else if (a != b && b != c)
                                        MessageBox.Show("Triângulo Escaleno");
                                }

                            else
                                MessageBox.Show("Não é triângulo");
                        }

                    else
                        MessageBox.Show("Não é triângulo");
                }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
