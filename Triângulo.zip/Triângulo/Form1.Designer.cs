﻿
namespace Triângulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.labelA = new System.Windows.Forms.Label();
            this.labelB = new System.Windows.Forms.Label();
            this.labelC = new System.Windows.Forms.Label();
            this.textA = new System.Windows.Forms.TextBox();
            this.textB = new System.Windows.Forms.TextBox();
            this.textC = new System.Windows.Forms.TextBox();
            this.butVer = new System.Windows.Forms.Button();
            this.groupMed = new System.Windows.Forms.GroupBox();
            this.butLimpar = new System.Windows.Forms.Button();
            this.groupMed.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelA
            // 
            this.labelA.AutoSize = true;
            this.labelA.BackColor = System.Drawing.Color.Transparent;
            this.labelA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelA.Location = new System.Drawing.Point(32, 33);
            this.labelA.Name = "labelA";
            this.labelA.Size = new System.Drawing.Size(57, 16);
            this.labelA.TabIndex = 0;
            this.labelA.Text = "Lado A";
            // 
            // labelB
            // 
            this.labelB.AutoSize = true;
            this.labelB.BackColor = System.Drawing.Color.Transparent;
            this.labelB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelB.Location = new System.Drawing.Point(32, 73);
            this.labelB.Name = "labelB";
            this.labelB.Size = new System.Drawing.Size(57, 16);
            this.labelB.TabIndex = 1;
            this.labelB.Text = "Lado B";
            // 
            // labelC
            // 
            this.labelC.AutoSize = true;
            this.labelC.BackColor = System.Drawing.Color.Transparent;
            this.labelC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelC.Location = new System.Drawing.Point(32, 115);
            this.labelC.Name = "labelC";
            this.labelC.Size = new System.Drawing.Size(57, 16);
            this.labelC.TabIndex = 2;
            this.labelC.Text = "Lado C";
            // 
            // textA
            // 
            this.textA.BackColor = System.Drawing.Color.White;
            this.textA.Location = new System.Drawing.Point(93, 30);
            this.textA.Name = "textA";
            this.textA.Size = new System.Drawing.Size(100, 24);
            this.textA.TabIndex = 3;
            this.textA.TextChanged += new System.EventHandler(this.textA_TextChanged);
            // 
            // textB
            // 
            this.textB.BackColor = System.Drawing.Color.White;
            this.textB.Location = new System.Drawing.Point(93, 70);
            this.textB.Name = "textB";
            this.textB.Size = new System.Drawing.Size(100, 24);
            this.textB.TabIndex = 4;
            // 
            // textC
            // 
            this.textC.BackColor = System.Drawing.Color.White;
            this.textC.Location = new System.Drawing.Point(93, 112);
            this.textC.Name = "textC";
            this.textC.Size = new System.Drawing.Size(100, 24);
            this.textC.TabIndex = 5;
            // 
            // butVer
            // 
            this.butVer.BackColor = System.Drawing.Color.Ivory;
            this.butVer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butVer.Location = new System.Drawing.Point(98, 220);
            this.butVer.Name = "butVer";
            this.butVer.Size = new System.Drawing.Size(124, 42);
            this.butVer.TabIndex = 6;
            this.butVer.Text = "Verificar";
            this.butVer.UseVisualStyleBackColor = false;
            this.butVer.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupMed
            // 
            this.groupMed.BackColor = System.Drawing.Color.Ivory;
            this.groupMed.Controls.Add(this.textC);
            this.groupMed.Controls.Add(this.labelA);
            this.groupMed.Controls.Add(this.labelB);
            this.groupMed.Controls.Add(this.textB);
            this.groupMed.Controls.Add(this.labelC);
            this.groupMed.Controls.Add(this.textA);
            this.groupMed.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupMed.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupMed.Location = new System.Drawing.Point(43, 45);
            this.groupMed.Name = "groupMed";
            this.groupMed.Size = new System.Drawing.Size(227, 150);
            this.groupMed.TabIndex = 7;
            this.groupMed.TabStop = false;
            this.groupMed.Text = "Medidas do Triângulo";
            // 
            // butLimpar
            // 
            this.butLimpar.BackColor = System.Drawing.Color.Ivory;
            this.butLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butLimpar.Location = new System.Drawing.Point(112, 279);
            this.butLimpar.Name = "butLimpar";
            this.butLimpar.Size = new System.Drawing.Size(98, 33);
            this.butLimpar.TabIndex = 8;
            this.butLimpar.Text = "Limpar";
            this.butLimpar.UseVisualStyleBackColor = false;
            this.butLimpar.Click += new System.EventHandler(this.butLimpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(319, 360);
            this.Controls.Add(this.butLimpar);
            this.Controls.Add(this.groupMed);
            this.Controls.Add(this.butVer);
            this.Name = "Form1";
            this.Text = "Triângulos";
            this.groupMed.ResumeLayout(false);
            this.groupMed.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelA;
        private System.Windows.Forms.Label labelB;
        private System.Windows.Forms.Label labelC;
        private System.Windows.Forms.TextBox textA;
        private System.Windows.Forms.TextBox textB;
        private System.Windows.Forms.TextBox textC;
        private System.Windows.Forms.Button butVer;
        private System.Windows.Forms.GroupBox groupMed;
        private System.Windows.Forms.Button butLimpar;
    }
}

